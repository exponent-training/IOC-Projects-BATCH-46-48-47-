package com.ServiceDAO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.Entity.Employee;

public interface ExponentDAO {

	public List<Employee> addEmployeeInDAO(Employee emp);

	public List<Employee> getEmployeesFromDao();

	public void deleteEmployeeDAO(int eid);

	public Employee editEmployeeUsingEIDDAO(int employeeId);

	public List<Employee> updateEmployeeUsingEIDDAO(Employee emp);

	public void uploadFileInDao(MultipartFile file);
}
