package com.Entity;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Document {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int fid;

	private String fileName;

	@Temporal(TemporalType.TIMESTAMP)
	private Date fileuploadTime;

	@Lob
	private byte[] fileData;

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getFileuploadTime() {
		return fileuploadTime;
	}

	public void setFileuploadTime(Date fileuploadTime) {
		this.fileuploadTime = fileuploadTime;
	}

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}

	@Override
	public String toString() {
		return "Document [fid=" + fid + ", fileName=" + fileName + ", fileuploadTime=" + fileuploadTime + ", fileData="
				+ Arrays.toString(fileData) + "]";
	}

}
