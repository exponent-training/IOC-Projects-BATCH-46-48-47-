package com.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.Entity.Employee;

public interface ExponentService {

	public List<Employee> addEmployee(Employee emp);

	public List<Employee> getEmployees();

	public void deleteEmployeeService(int eid);

	public Employee editEmployeeUsingEIDService(int employeeId);

	public List<Employee> updateEmployeeUsingEIDService(Employee emp);

	public void uploadFileInService(MultipartFile file);
}
