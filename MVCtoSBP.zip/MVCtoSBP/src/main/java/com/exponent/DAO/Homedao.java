package com.exponent.DAO;

import com.exponent.Entity.Employee;

public interface Homedao {

	void registerEmployeeInDao(Employee emp);

}
