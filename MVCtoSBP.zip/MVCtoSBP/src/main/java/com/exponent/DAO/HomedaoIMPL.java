package com.exponent.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.exponent.Entity.Employee;

@Repository
public class HomedaoIMPL implements Homedao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void registerEmployeeInDao(Employee emp) {

		System.out.println("Dao Layer :" + emp);
		Session s = sf.openSession();

		s.save(emp);

		s.beginTransaction().commit();
		System.out.println("Data inserted!!");

	}

}
