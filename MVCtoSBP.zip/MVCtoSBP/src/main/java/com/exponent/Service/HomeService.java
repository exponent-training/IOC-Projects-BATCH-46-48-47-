package com.exponent.Service;

import com.exponent.Entity.Employee;

public interface HomeService {

	void registerEmployeeinService(Employee emp);

}
