package com.exponent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvCtoSbpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvCtoSbpApplication.class, args);
	}

}
