package com.exponent.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping("/")
	public String getsg() {

		logger.trace("application loaded");
		logger.debug("application debug success");
		logger.info("Application started");
		logger.warn("Application contains int value only");
		logger.error("exception occured");

		return "welcome to Exponent";
	}

}
