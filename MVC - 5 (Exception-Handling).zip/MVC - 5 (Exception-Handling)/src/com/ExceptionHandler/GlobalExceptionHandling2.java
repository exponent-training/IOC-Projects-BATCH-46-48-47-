package com.ExceptionHandler;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandling2 {

	@ExceptionHandler(value = ArithmeticException.class)
	public String ArithmaticHandle() {

		System.out.println("Global Exception handles This Exception :- Arithamatic");
		return "success";
	}

	@ExceptionHandler(value = NullPointerException.class)
	public String NullpointerHandlHere() {

		System.out.println("Global Exception handles by GlobalExceptionclass2 This Exception :- Nullpointer  This is last warning!!");
		return "success";
	}

}
