package com.ServiceDAOIMPL;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.Employee;
import com.ServiceDAO.ExponentDAO;

@Repository
public class ExponentDAOIMPL implements ExponentDAO {

	@Autowired
	private SessionFactory sf;

	@Override
	public List<Employee> addEmployeeInDAO(Employee emp) {

		System.out.println(" I am in Dao Layer ");
		Session s = sf.openSession();
		s.save(emp);
		s.beginTransaction().commit();
		System.out.println("Employee added");

		Query query = s.createQuery("from Employee");

		return query.getResultList();

	}

}
