package com;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.Employee;
import com.Service.ExponentService;

@Controller
public class HomeController {

	@Autowired
	private ExponentService exs;

	private final static String USERNAME = "admin";
	private final static String PASSWORD = "admin123";

	@RequestMapping(value = "/log")
	public String getMsg(@RequestParam("username") String un, @RequestParam("password") String ps) {

		System.out.println("Username :- " + un);
		System.out.println("Password :- " + ps);

		if (un.equalsIgnoreCase(USERNAME) && ps.equalsIgnoreCase(PASSWORD)) {

			return "success";

		} else {
			return "login";
		}

	}

	// username , password -> regun , regps == login , login

	@RequestMapping(value = "/reg")
	public String registerEmployee(@ModelAttribute Employee emp, Model model) {

		List<Employee> lie = exs.addEmployee(emp);

		model.addAttribute("msg", lie);

		System.out.println(lie);

		System.out.println("Employee info");
		System.out.println(emp);

		if (emp != null) {
			return "login";
		} else {
			return "register";
		}

	}
}
