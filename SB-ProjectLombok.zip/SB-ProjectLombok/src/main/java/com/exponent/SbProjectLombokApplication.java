package com.exponent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exponent.Entity.Employee;

@SpringBootApplication
public class SbProjectLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbProjectLombokApplication.class, args);
		
		
		Employee emp = new Employee();
		emp.setEid(101);
		emp.setEname("Raju");
		emp.setEaddress("PCMC");
		
		System.out.println(emp);
	}

}
