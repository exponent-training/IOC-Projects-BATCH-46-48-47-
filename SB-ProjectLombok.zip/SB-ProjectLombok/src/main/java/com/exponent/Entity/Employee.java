package com.exponent.Entity;

import lombok.Data;

@Data
public class Employee {

	private int eid;

	private String ename;

	private String eaddress;
}


