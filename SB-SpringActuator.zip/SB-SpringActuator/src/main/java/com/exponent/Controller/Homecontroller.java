package com.exponent.Controller;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Endpoint(id = "cendpoint")
public class Homecontroller {

//	@Value(value = "${myapplication}")
//	private String msg;

	
	@ReadOperation
	public String customeEndoint() {
		return "This is Custome Endpoint i am dieing please save me!!!!";
	}
}