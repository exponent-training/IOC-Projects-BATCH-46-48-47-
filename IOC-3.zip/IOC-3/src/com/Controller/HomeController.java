package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Entity.Employee;

public class HomeController {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");

		/*
		 * Employee emp1 = apc.getBean("emp", Employee.class);
		 * System.out.println(emp1.hashCode());
		 * System.out.println(emp1.getEaddress().hashCode());
		 * 
		 * System.out.println("----------------------------------------------------");
		 * 
		 * Employee emp2 = apc.getBean("emp", Employee.class);
		 * System.out.println(emp2.hashCode());
		 * System.out.println(emp2.getEaddress().hashCode());
		 */

		Employee emp1 = apc.getBean("emp", Employee.class);
		System.out.println(emp1);
	}
}
