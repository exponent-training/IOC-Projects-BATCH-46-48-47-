package com.ServiceDAOIMPL;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.Employee;
import com.ServiceDAO.ExponentDAO;

@Repository
public class ExponentDAOIMPL implements ExponentDAO {

	@Autowired
	private SessionFactory sf;

	@Override
	public List<Employee> addEmployeeInDAO(Employee emp) {

		System.out.println(" I am in Dao Layer ");
		Session s = sf.openSession();
		s.save(emp);
		s.beginTransaction().commit();
		System.out.println("Employee added");

		Query query = s.createQuery("from Employee");

		return query.getResultList();

	}

	@Override
	public List<Employee> getEmployeesFromDao() {
		Session s = sf.openSession();
		Query query = s.createQuery("from Employee");
		List listOfEmp = query.getResultList();

		return listOfEmp;
	}

	@Override
	public void deleteEmployeeDAO(int eid) {

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("delete from Employee where eid=:id");
		query.setParameter("id", eid);
		query.executeUpdate();
		tx.commit();

		System.out.println("Data DEleted Successfully");

	}

	@Override
	public Employee editEmployeeUsingEIDDAO(int employeeId) {

		Session session = sf.openSession();

		Employee employee = session.get(Employee.class, employeeId);

		session.beginTransaction().commit();

		return employee;
	}

	@Override
	public List<Employee> updateEmployeeUsingEIDDAO(Employee emp) {
		// Get the current Hibernate session

		System.out.println("Dao Layer");
		System.out.println(emp);

		Session session = sf.getCurrentSession();
		Transaction tx = session.beginTransaction();

		session.update(emp);

		Query query = session.createQuery("from Employee");
		List<Employee> lemp = query.getResultList();
		tx.commit();

		return lemp;
	}

}
