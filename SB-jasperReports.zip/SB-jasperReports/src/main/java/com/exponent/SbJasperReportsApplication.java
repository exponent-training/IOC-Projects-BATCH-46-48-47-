package com.exponent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbJasperReportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbJasperReportsApplication.class, args);
	}

}
