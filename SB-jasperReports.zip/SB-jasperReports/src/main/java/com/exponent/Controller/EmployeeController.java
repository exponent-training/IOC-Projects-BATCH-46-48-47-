package com.exponent.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exponent.Entity.Employee;
import com.exponent.Service.EmployeeService;

import net.sf.jasperreports.engine.JRException;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService es;

	@PostMapping("/employeeadd")
	public ResponseEntity<?> addEmployee(@RequestBody Employee emp) {

		System.out.println(emp);

		es.addEMployeeInService(emp);

		return new ResponseEntity("success", HttpStatus.OK);

	}

	@GetMapping("/report/{format}")
	public ResponseEntity<?> addEmployee(@PathVariable String format) throws JRException {

		es.reportGeneration(format);

		return new ResponseEntity("repot generated!!", HttpStatus.OK);

	}

}
