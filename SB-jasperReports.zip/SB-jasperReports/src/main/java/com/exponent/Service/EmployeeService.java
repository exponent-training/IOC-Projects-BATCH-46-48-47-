package com.exponent.Service;

import com.exponent.Entity.Employee;

import net.sf.jasperreports.engine.JRException;

public interface EmployeeService {

	void addEMployeeInService(Employee emp);

	void reportGeneration(String format) throws JRException;

}
