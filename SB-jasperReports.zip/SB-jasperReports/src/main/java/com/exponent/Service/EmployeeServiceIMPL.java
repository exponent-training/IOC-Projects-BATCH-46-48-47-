package com.exponent.Service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.exponent.Entity.Employee;
import com.exponent.Repositiry.EmployeeRepo;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;

@Service
public class EmployeeServiceIMPL implements EmployeeService {

	@Autowired
	private EmployeeRepo er;

	@Override
	public void addEMployeeInService(Employee emp) {

		er.save(emp);

	}

	@Override
	public void reportGeneration(String format) throws JRException {

		List<Employee> employees = er.findAll();

		try {
			// 1 load file
			File file = ResourceUtils.getFile("classpath:EmployeeDetails.jrxml");

			// compile report
			JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());

			// datasource creation -> data -> report
			JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(employees);

			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("created by", "exponent");

			// filling data inside report.
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);

			// checking format of report
			if (format.equalsIgnoreCase("html")) {
				JasperExportManager.exportReportToHtmlFile(jasperPrint, "C:\\reports\\employees.html");
			} else if (format.equalsIgnoreCase("pdf")) {
				JasperExportManager.exportReportToPdfFile(jasperPrint, "C:\\reports\\employees.pdf");
			} else if (format.equalsIgnoreCase("csv")) {

				JRCsvExporter csvfile = new JRCsvExporter();

				csvfile.setExporterInput(new SimpleExporterInput(jasperPrint));

				csvfile.setExporterOutput(new SimpleWriterExporterOutput("C:\\reports\\employees.csv"));

				csvfile.exportReport();

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
