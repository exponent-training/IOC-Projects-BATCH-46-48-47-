package com.Entity;

public class Address {

	private int pincode;

	private String country;

	private String address;

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Address [pincode=" + pincode + ", country=" + country + ", address=" + address + "]";
	}

}
