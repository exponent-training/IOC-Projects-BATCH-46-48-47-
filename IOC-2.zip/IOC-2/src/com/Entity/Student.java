package com.Entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Student {

	private int sid;

	private String sname;

	private List<Integer> smarks = new ArrayList<Integer>();

	private Map<Integer, String> saddress = new HashMap<Integer, String>();

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public List<Integer> getSmarks() {
		return smarks;
	}

	public void setSmarks(List<Integer> smarks) {
		this.smarks = smarks;
	}

	public Map<Integer, String> getSaddress() {
		return saddress;
	}

	public void setSaddress(Map<Integer, String> saddress) {
		this.saddress = saddress;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", smarks=" + smarks + ", saddress=" + saddress + "]";
	}

}
