package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Entity.Employee;
import com.Entity.Student;

public class HomeController {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
		Employee emp1 = apc.getBean("emp", Employee.class);

		System.out.println(emp1);

		System.out.println("-----------------------------------");

		/*
		 * Student student = apc.getBean("stu", Student.class);
		 * 
		 * System.out.println(student); System.out.println("--Student Marks--");
		 * System.out.println(student.getSmarks());
		 * System.out.println("--Student Locations--");
		 * System.out.println(student.getSaddress());
		 */

	}
}
