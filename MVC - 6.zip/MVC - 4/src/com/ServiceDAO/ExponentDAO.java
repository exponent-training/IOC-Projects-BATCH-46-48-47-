package com.ServiceDAO;

import java.util.List;

import com.Entity.Employee;

public interface ExponentDAO {

	public List<Employee> addEmployeeInDAO(Employee emp);

	public List<Employee> getEmployeesFromDao();

	public void deleteEmployeeDAO(int eid);
}
