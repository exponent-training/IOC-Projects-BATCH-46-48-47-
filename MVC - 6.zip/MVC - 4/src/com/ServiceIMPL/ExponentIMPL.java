package com.ServiceIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entity.Employee;
import com.Service.ExponentService;
import com.ServiceDAO.ExponentDAO;

@Service
class ExponentIMPL implements ExponentService {

	@Autowired
	private ExponentDAO exdao;

	@Override
	public List<Employee> addEmployee(Employee emp) {

		System.out.println("I am in Service layer ");
		return exdao.addEmployeeInDAO(emp);

	}

	@Override
	public List<Employee> getEmployees() {

		return exdao.getEmployeesFromDao();
	}

	@Override
	public void deleteEmployeeService(int eid) {

		exdao.deleteEmployeeDAO(eid);

	}

}
