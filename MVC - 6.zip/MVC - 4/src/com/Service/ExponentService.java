package com.Service;

import java.util.List;

import com.Entity.Employee;

public interface ExponentService {

	public List<Employee> addEmployee(Employee emp);

	public List<Employee> getEmployees();

	public void deleteEmployeeService(int eid);
}
