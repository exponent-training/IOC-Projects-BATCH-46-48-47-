package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {

	@Bean(name = "add")
	public Address getadd() {
		Address ad = new Address();
		ad.setPincode(256151);
		ad.setCountry("IND");

		return ad;
	}

	/*
	 * @Bean(name = "sad") public Address getadd1() { Address ad = new Address();
	 * ad.setPincode(44564); ad.setCountry("US");
	 * 
	 * return ad; }
	 */

	@Bean(name = "stu")
	public Student getStudent() {
		Student st = new Student();
		st.setSid(101);
		st.setSname("Raju");
		return st;

	}

}
