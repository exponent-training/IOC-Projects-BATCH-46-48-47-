package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Controller {

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Student st = apc.getBean("stu", Student.class);
		System.out.println(st);

		// Collections properties
		// IOC - Class Managment

	}
}
