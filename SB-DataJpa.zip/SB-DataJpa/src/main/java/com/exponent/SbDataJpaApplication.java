package com.exponent;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.hibernate.criterion.Example;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import com.exponent.entity.Employee;
import com.exponent.repository.EmployeeRepository;

@SpringBootApplication
public class SbDataJpaApplication {

	private static String string;

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SbDataJpaApplication.class, args);

		EmployeeRepository errepo = context.getBean(EmployeeRepository.class);

		Employee emp1 = new Employee();
		emp1.setEid(101);
		emp1.setEname("karan");
		emp1.setErole("SE");
		emp1.setEaddress("PUNE");
		emp1.setEsalary(45000.0);

		Employee emp2 = new Employee();
		emp2.setEid(102);
		emp2.setEname("raju");
		emp2.setErole("TS");
		emp2.setEaddress("MUMBAI");
		emp2.setEsalary(65000.0);

		Employee emp3 = new Employee();
		emp3.setEid(103);
		emp3.setEname("ravi");
		emp3.setErole("CE");
		emp3.setEaddress("BANGLORE");
		emp3.setEsalary(10000.0);

//		errepo.saveAll(Arrays.asList(emp1, emp2, emp3));

		/*
		 * Optional<Employee> employee = errepo.findById(5);
		 * 
		 * if (employee.isPresent()) { System.out.println(employee); } else {
		 * System.out.println("Employee Not present"); }
		 */

		/*
		 * Iterable<Employee> alldata = errepo.findAll(); for (Employee employee :
		 * alldata) { System.out.println(employee); }
		 */

		/*
		 * Iterable<Employee> findAllById = errepo.findAllById(Arrays.asList(1, 2));
		 * 
		 * for (Employee employee : findAllById) { System.out.println(employee); }
		 */

//		System.out.println(errepo.count());

		/*
		 * List<Employee> only2EMployeePerPage = errepo.findAll(PageRequest.of(2,
		 * 2)).getContent();
		 * 
		 * for (Employee employee : only2EMployeePerPage) {
		 * System.out.println(employee); }
		 */

		/*
		 * List<Employee> findAll = errepo.findAll(Sort.by("esalary").by("eaddress"));
		 * 
		 * for (Employee employee : findAll) { System.out.println(employee); }
		 */

	}

}
